'user strict';
const bcrypt = require('bcryptjs');  // Using bcrypt for secure password hashing
const jwt = require('jsonwebtoken');
const { user } = require('../../orm');
const { check, validationResult } = require('express-validator');  // To validate inputs
const csurf = require('csurf');  // For CSRF protection
const sanitize = require('sanitize-html');  // For sanitizing inputs to prevent XSS

// CSRF protection middleware
const csrfProtection = csurf({ cookie: true });

module.exports = (app, db) => {

    // Front End entry page
    /**
     * GET /
     * @summary Front End Entry Page (SSTI - Server Side Template Injection)(Reflected XXS - Cross Site Scripting)
     * @tags frontend
     * @param {string} message.query - a message to present to the user
     */
    app.get('/', (req, res) => {
        console.log(req.session);
        
        const nunjucks = require('nunjucks');
        const message = req.query.message || "Please log in to continue";
        
        // Sanitize message to prevent XSS and SSTI
        const sanitizedMessage = sanitize(message);

        // Use the sanitized message in the template
        res.render('user.html', { message: sanitizedMessage });
    });

    // Front End register page
    /**
     * GET /register
     * @summary Front End Entry Page
     * @tags frontend
     * @param {string} message.query - a message to present to the user
     */
    app.get('/register', (req, res) => {
        const nunjucks = require('nunjucks');
        const message = req.query.message || "Please log in to continue";
        
        // Sanitize message to prevent XSS
        const sanitizedMessage = sanitize(message);
        res.render('user-register.html', { message: sanitizedMessage });
    });

    // Front End route to Register
    /**
     * GET /registerform
     * @summary Front End Route to Register
     * @tags frontend
     * @param {string} email.query.required - email body parameter
     * @param {string} password.query.required - password body parameter
     * @param {string} name.query.required - name body parameter
     * @param {string} address.query.required - address body parameter
     */
    app.get('/registerform', [
        check('email').isEmail().withMessage('Invalid email format'),
        check('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters')
    ], (req, res) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }

        const userEmail = req.query.email;
        const userName = req.query.name;
        const userRole = 'user';
        const userPassword = req.query.password;
        const userAddress = req.query.address;

        // Sanitize inputs to prevent XSS
        const sanitizedEmail = sanitize(userEmail);
        const sanitizedName = sanitize(userName);
        const sanitizedAddress = sanitize(userAddress);

        // Hash password using bcrypt before saving
        bcrypt.hash(userPassword, 10, (err, hashedPassword) => {
            if (err) {
                return res.status(500).json({ error: 'Error hashing password' });
            }

            db.user.create({
                name: sanitizedName,
                email: sanitizedEmail,
                role: userRole,
                address: sanitizedAddress,
                password: hashedPassword
            }).then(new_user => {
                res.redirect('/profile?id=' + new_user.id);
            }).catch(e => {
                console.log(e);
                res.redirect('/?message=Error registering, please try again');
            });
        });
    });

    // Front End route to log in
    /**
     * GET /login
     * @summary Log in page
     * @tags frontend
     * @param {string} message.query - a message to present to the user
     * @param {string} email.query.required - email body parameter
     * @param {string} password.query.required - password body parameter
     */
    app.get('/login', (req, res) => {
        const userEmail = req.query.email;
        const userPassword = req.query.password;
        console.log(req.query.message);

        const user = db.user.findAll({
            where: { email: userEmail }
        }).then(user => {
            if (user.length == 0) {
                res.redirect('/?message=Password was not found! Please Try again');
                return;
            }

            bcrypt.compare(userPassword, user[0].password, (err, isMatch) => {
                if (!isMatch) {
                    res.redirect('/?message=Password was not correct, please try again');
                    return;
                }

                req.session.logged = true;
                res.redirect('/profile?id=' + user[0].id);
            });
        });
    });

    // Front End route to profile
    /**
     * GET /profile
     * @summary View user profile
     * @tags frontend
     * @param {string} message.query - a message to present to the user
     * @param {number} id.query.required - Id number of the profile holder
     * @param {string} profile_description
     */
    app.get('/profile', (req, res) => {
        if (!req.query.id) {
            res.redirect("/?message=Could not Access profile please log in or register");
            return;
        }

        const user = db.user.findAll({
            include: 'beers',
            where: { id: req.query.id }
        }).then(user => {
            if (user.length == 0) {
                res.redirect('/?message=User not found, please log in');
                return;
            }

            db.beer.findAll().then(beers => {
                res.render('profile.html', { beers: beers, user: user[0] });
            });
        });
    });

    // Front End route to beer
    /**
     * GET /beer
     * @summary View beer details
     * @tags frontend
     * @param {number} id.query.required - Beer id
     * @param {number} user.query.required - User id
     * @param {string} relationship - The message a user gets when loving a beer
     */
    app.get('/beer', (req, res) => {
        if (!req.query.id) {
            res.redirect("/?message=Could not Access beer please try a different beer");
            return;
        }

        const beer = db.beer.findAll({
            include: 'users',
            where: { id: req.query.id }
        }).then(beer => {
            if (beer.length == 0) {
                res.redirect('/?message=Beer not found, please try again');
                return;
            }

            db.user.findOne({ where: { id: req.query.user } }).then(user => {
                if (!user) {
                    res.redirect('/?message=User not found, please try again');
                    return;
                }

                user.hasBeer(beer).then(result => {
                    let love_message = result ? "You Love THIS BEER!!" : "...";
                    if (req.query.relationship) {
                        love_message = req.query.relationship;
                    }

                    res.render('beer.html', { beers: beer, message: love_message, user: user });
                });
            });
        });
    });

};
