'user strict';
const bcrypt = require('bcryptjs');  // Added bcrypt for password hashing
const jwt = require('jsonwebtoken');
const { user } = require('../../orm');
const { check, validationResult } = require('express-validator');  // Validation library for inputs
const otplib = require('otplib');  // OTP generation and verification

module.exports = (app, db) => {

    // Get all users
    /**
     * GET /v1/admin/users/ 
     * @summary List all users (Unverified JWT Manipulation)(Authorization Bypass)
     * @tags admin
     * @security BearerAuth
     * @return {array<User>} 200 - success response - application/json
     */
    app.get('/v1/admin/users/', (req, res) => {
        if (req.headers.authorization) {
            try {
                const user_object = jwt.verify(req.headers.authorization.split(' ')[1], "SuperSecret");

                // Check if the role is 'admin'
                if (user_object.role == 'admin') {
                    db.user.findAll({ include: "beers" })
                        .then((users) => {
                            res.json(users);
                        })
                        .catch((e) => {
                            res.status(500).json({ error: "Error fetching users: " + e });
                        });
                } else {
                    res.status(403).json({ error: "Not Admin, access denied" });
                }

            } catch (e) {
                res.status(401).json({ error: "Unauthorized: " + e.message });
            }
        } else {
            res.status(400).json({ error: "Missing token in header" });
        }
    });

    // Get information about other users
    /**
     * GET /v1/user/{user_id}
     * @summary Get information of a specific user
     * @tags user
     * @param {integer} user_id.path.required - user id to get information
     * @return {array<User>} 200 - success response - application/json
     */
    app.get('/v1/user/:id', (req, res) => {
        db.user.findOne({ include: 'beers', where: { id: req.params.id } })
            .then(user => {
                res.json(user);
            })
            .catch(err => {
                res.status(500).json({ error: 'Error fetching user: ' + err });
            });
    });

    // Delete a specific user
    /**
     * DELETE /v1/user/{user_id} 
     * @summary Delete a specific user (Broken Function Level Authentication)
     * @tags user
     * @param {integer} user_id.path.required - user id to delete (Broken Function Level)
     * @return {array<User>} 200 - success response - application/json
     */
    app.delete('/v1/user/:id', (req, res) => {
        const token = req.headers.authorization.split(' ')[1];
        try {
            const decoded = jwt.verify(token, 'SuperSecret');
            if (decoded.role === 'admin') {
                db.user.destroy({ where: { id: req.params.id } })
                    .then(() => {
                        res.json({ result: "User deleted" });
                    })
                    .catch(e => {
                        res.status(500).json({ error: e });
                    });
            } else {
                res.status(403).json({ error: "Admin privileges required" });
            }
        } catch (err) {
            res.status(401).json({ error: "Unauthorized: " + err.message });
        }
    });

    // Create a new user
    /**
     * POST /v1/user/
     * @summary create a new user (Weak Password)(ReDos - Regular Expression Denial of Service)
     * @tags user
     * @param {User} request.body.required - User
     * @return {object} 200 - user response
     */
    app.post('/v1/user/', [
        check('email').isEmail().withMessage('Invalid email format'),
        check('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters')
    ], (req, res) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }

        const userEmail = req.body.email;
        const userName = req.body.name;
        const userRole = req.body.role;
        const userPassword = req.body.password;
        const userAddress = req.body.address;

        bcrypt.hash(userPassword, 10, (err, hashedPassword) => {
            if (err) {
                return res.status(500).json({ error: "Error hashing password" });
            }

            db.user.create({
                name: userName,
                email: userEmail,
                role: userRole,
                address: userAddress,
                password: hashedPassword
            }).then(new_user => {
                res.json(new_user);
            }).catch(e => {
                res.status(500).json({ error: e });
            });
        });
    });

    // Make a user love a beer
    /**
     * GET /v1/love/{beer_id}
     * @summary make a user love a beer(CSRF - Client Side Request Forgery GET)
     * @tags user
     * @param {integer} beer_id.path.required - Beer Id
     * @param {integer} id.query - User ID
     * @param {boolean} front.query - is it a frontend redirect ?
     * @return {object} 200 - user response
     */
    app.get('/v1/love/:beer_id', (req, res) => {
        var current_user_id = req.query.id;
        var front = req.query.front || false;

        if (!current_user_id) {
            res.status(400).json({ error: 'User ID missing' });
            return;
        }

        const beer_id = req.params.beer_id;
        db.beer.findOne({ where: { id: beer_id } })
            .then(beer => {
                db.user.findOne({ where: { id: current_user_id }, include: 'beers' })
                    .then(current_user => {
                        if (current_user) {
                            current_user.hasBeer(beer).then(result => {
                                if (!result) {
                                    current_user.addBeer(beer, { through: 'user_beers' });
                                }
                                if (front) {
                                    res.redirect(`/beer?user=${current_user_id}&id=${beer_id}&message=You Just Loved this beer!!`);
                                } else {
                                    res.json(current_user);
                                }
                            });
                        } else {
                            res.status(404).json({ error: 'User not found' });
                        }
                    });
            }).catch(e => {
                res.status(500).json(e);
            });
    });

    // Insecure JWT Implementation - Login and Token Generation
    /**
     * POST /v1/user/token
     * @summary login endpoint to get jwt token - (Insecure JWT Implementation)
     * @tags user
     * @param {LoginUserDTO} request.body.required - user login credentials - application/json       
     * @return {string} 200 - success
     * @return {string} 404 - user not found
     * @return {string} 401 - wrong password
    */
    app.post('/v1/user/token', (req, res) => {
        const userEmail = req.body.email;
        const userPassword = req.body.password;

        db.user.findOne({ where: { email: userEmail } })
            .then(user => {
                if (!user) {
                    res.status(404).send({ error: 'User not found' });
                    return;
                }

                bcrypt.compare(userPassword, user.password, (err, isMatch) => {
                    if (!isMatch) {
                        res.status(401).json({ error: 'Incorrect password' });
                        return;
                    }

                    const payload = { id: user.id, role: user.role };
                    const token = jwt.sign(payload, "SuperSecret", { expiresIn: 86400 });

                    res.status(200).json({ jwt: token, user });
                });
            }).catch(err => {
                res.status(500).send({ error: 'Error logging in' });
            });
    });

};
