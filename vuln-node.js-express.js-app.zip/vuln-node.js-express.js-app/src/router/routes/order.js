'user strict';
var fs = require('fs');
var path = require('path');
const sanitize = require('sanitize-html');  // Import a library for sanitization

module.exports = (app, db) => {
    app.get('/v1/order', (req, res) => {
        db.beer.findAll({ include: "users" })
            .then(beer => {
                res.json(beer);
            });
    });

    app.get('/v1/beer-pic/', (req, res) => {
        var filename = req.query.picture;
        var filePath = path.normalize(`../../../uploads/${filename}`);

        // Path Traversal Fix: Ensure the filename does not contain '..' or try to navigate outside the intended directory
        if (filePath.includes('..') || filePath.indexOf(__dirname) !== 0) {
            return res.status(400).send('Invalid file path');
        }

        fs.readFile(path.join(__dirname, filePath), function (err, data) {
            if (err) {
                return res.status(500).send("Error reading file");
            } else {
                const extname = path.extname(filename).toLowerCase();
                if (extname === '.jpg' || extname === '.jpeg' || extname === '.png' || extname === '.gif') {
                    res.type(extname); // Set the correct Content-Type based on file extension
                    res.send(data);
                } else {
                    res.status(415).send('Unsupported file type');
                }
            }
        });
    });

    app.get('/v1/search/:filter/:query', (req, res) => {
        const filter = req.params.filter;
        const query = req.params.query;

        // Check allowed filters to prevent unexpected input
        const validFilters = ['name', 'type', 'brewery'];
        if (!validFilters.includes(filter)) {
            return res.status(400).send('Invalid filter');
        }

        // Use prepared statements to prevent SQL Injection
        const sql = "SELECT * FROM beers WHERE ?? = ?";
        db.sequelize.query(sql, { replacements: [filter, query], type: db.Sequelize.QueryTypes.SELECT })
            .then(beers => {
                res.status(200).send(beers);
            }).catch(function (err) {
                res.status(501).send("Error, query failed: " + err);
            });
    });
};
