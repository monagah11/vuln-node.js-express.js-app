git init
npm init
npm install express
npm install --global mocha
npm install -g nodemon
npm install sqlite3
npm install sequelize
npm install dotenv
npm install swagger-jsdoc
npm install swagger-ui-express
npm install swagger-sequelize
npm install sequelize-json-schema
npm install libxmljs multer
npm install libxml
npm install passport
npm install md5
npm install express-session cookie-parser
npm install --save-dev sequelize-cli
npm install passport-jwt jsonwebtoken
npm install otplib
npm install node-serialize
npm install axios
npm install nunjucks
npm install express-formidable